<!DOCTYPE html>
<html lang="en">
<body id="header">
    <nav>
        <div class="topnav" id="myTopnav">
            <a href="Unit3_store.php" class="active">Home</a>
            <a href="#KeyCaps" target="_self">Key Caps</a>
            <a href="#Switches" target="_self">Switches</a>
            <a id="admin" href="Unit3_admin.php" target="_self">Admin</a>
        </div>
    </nav>
    <header>
        <h1>Key Wave</h1>
        <p>Proudly letting you surf the waves on your keyboard since 2023</p>
    </header>
</body>
</html>