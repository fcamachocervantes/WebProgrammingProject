<?php
    $servername = "localhost";
    $username = "fcamachocervantes";
    $password = "vJ[O1VjW!amVZ91.";
    $database = "fcamachocervantes";
?>