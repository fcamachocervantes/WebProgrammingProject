<!DOCTYPE html>
<html lang="en">
<body id="header">
    <nav>
        <div class="topnav" id="myTopnav">
            <a id="store" href="Unit5_store.php" target="_self">Store</a>
            <a href="Unit5_order_entry.php" target="_self">Order Entry</a>
            <a href="Unit5_adminProduct.php" target="_self">Products</a>
            <a id="admin" href="Unit5_admin.php" target="_self">Admin</a>
        </div>
    </nav>
    <header>
        <h1>Key Wave</h1>
        <p>Proudly letting you surf the waves on your keyboard since 2023</p>
    </header>
</body>
</html>