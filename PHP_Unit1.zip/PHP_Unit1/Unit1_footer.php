<!DOCTYPE html>
<html lang="en">
<body>
    <footer>
        <p>Trouble finding the right wave?</p>
        <p>Contact us: keyboard@Keywave.com</p>
    </footer>
</body>

</html>