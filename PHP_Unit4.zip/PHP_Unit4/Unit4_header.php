<!DOCTYPE html>
<html lang="en">
<body id="header">
    <nav>
        <div class="topnav" id="myTopnav">
            <a href="Unit4_store.php" class="active">Store</a>
            <a href="Unit4_order_entry.php" target="_self">Order Entry</a>
            <a id="admin" href="Unit4_admin.php" target="_self">Admin</a>
        </div>
    </nav>
    <header>
        <h1>Key Wave</h1>
        <p>Proudly letting you surf the waves on your keyboard since 2023</p>
    </header>
</body>
</html>